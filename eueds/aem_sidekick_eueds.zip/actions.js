/*
 * Copyright 2023 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import { log } from './log.js';
import { addCacheBusterRule } from './cache-buster.js';
import { setAuthToken } from './auth.js';
import {
  addProject,
  toggleProject,
  deleteProject,
  isValidProject,
  getProject,
  getProjects,
  getProjectMatches,
  updateProject as updateProjectConfig,
} from './project.js';
import { ADMIN_ORIGIN, ADMIN_ORIGIN_NEW, createAdminUrl } from './utils/admin.js';
import { getConfig } from './config.js';
import { getDisplay, setDisplay } from './display.js';
import { urlCache } from './url-cache.js';
import { saveDocument } from './sharepoint.js';

/**
 * Updates the auth token via external messaging API (admin only).
 * @param {Object} message The message object
 * @param {string} message.owner The project owner
 * @param {string} message.repo The project repo
 * @param {string} message.authToken The auth token
 * @param {number} [message.exp] The auth token expiry in seconds since epoch
 * @param {string} [message.siteToken] The auth token
 * @param {number} [message.siteTokenExpiry] The site token expiry in seconds since epoch
 * @param {string} [message.picture] The user picture
 * @param {chrome.runtime.MessageSender} sender The sender
 * @returns {Promise<string>} The action's response
 */
async function updateAuthToken({
  owner,
  repo,
  authToken,
  exp: authTokenExpiry,
  siteToken,
  siteTokenExpiry,
  picture,
}, { tab }) {
  if (owner) {
    try {
      const { origin } = new URL(tab.url);
      if ((origin === ADMIN_ORIGIN || origin === ADMIN_ORIGIN_NEW)
        && authToken !== undefined) {
        await setAuthToken(
          owner,
          repo,
          authToken,
          authTokenExpiry,
          siteToken,
          siteTokenExpiry,
          picture,
        );
        return 'close';
      }
    } catch (e) {
      // ignore
    }
  }
  return 'invalid message';
}

/**
 * Shows the sidekick if it is hidden.
 */
export async function showSidekickIfHidden() {
  const visible = await getDisplay();
  if (!visible) {
    await setDisplay(true);
    // wait for sidekick to be visible and check tab to be called by storage listener
    // eslint-disable-next-line no-promise-executor-return
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
}

/**
 * Notification confirmation callback
 * @param {number} tabId The tab ID
 */
export function notificationConfirmCallback(tabId) {
  return async () => {
    await chrome.tabs.reload(tabId, { bypassCache: true });
  };
}

/**
 * Waits for the sidekick's message listener to be ready in a tab.
 * @param {number} tabId The tab ID
 * @param {number} [timeout=10000] Maximum time to wait in ms
 */
/* eslint-disable no-await-in-loop */
async function waitForSidekick(tabId, timeout = 10000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    try {
      const resp = await chrome.tabs.sendMessage(tabId, { action: 'ping' });
      if (resp) {
        return;
      }
    } catch (e) {
      // sidekick not ready yet
    }
    await new Promise((resolve) => {
      setTimeout(resolve, 200);
    });
  }
}
/* eslint-enable no-await-in-loop */

/**
 * Shows a notification in the sidekick
 * @param {*} data
 * @param {*} callback
 */
export async function showSidekickNotification(tabId, data, callback) {
  return chrome.tabs.sendMessage(tabId, { action: 'show_notification', ...data }, callback);
}

/**
 * Verifies if the origin that requested the organisations is a trusted one.
 * @param {string} origin
 * @returns {boolean} true - trusted / false - untrusted
 */
function isTrustedOrigin(origin) {
  const TRUSTED_ORIGINS = [
    ADMIN_ORIGIN,
    ADMIN_ORIGIN_NEW,
    `https://tools.eueds.live`,
    'http://localhost:3000',
  ];

  if (TRUSTED_ORIGINS.includes(origin)) {
    return true;
  }

  const TRUSTED_ORIGIN_PATTERNS = [
    // labs website preview/live: <ref>--*helix-labs-website--<org>.<prefix>.page|live
    new RegExp(`^https://[a-z0-9-]+--[a-z0-9-]*helix-labs-website--adobe-ssa-eds\\.eueds\\.(page|live)$`),
    // tools website preview/live
    new RegExp(`^https://[a-z0-9-]+--[a-z0-9-]*helix-tools-website--adobe-ssa-eds\\.eueds\\.(page|live)$`),
  ];

  if (TRUSTED_ORIGIN_PATTERNS.some((trustedOriginPattern) => origin.match(trustedOriginPattern))) {
    return true;
  }

  return false;
}

/**
 * Returns the organizations the user is currently authenticated for.
 * @returns {Promise<string[]>} The organizations
 */
async function getAuthInfo(_, { tab }) {
  const { origin } = new URL(tab.url);
  if (!isTrustedOrigin(origin)) {
    return []; // don't give out any information
  }

  const projects = await getConfig('session', 'projects') || [];
  return projects
    .filter(({ authToken, authTokenExpiry }) => !!authToken && authTokenExpiry > Date.now())
    .map(({ owner }) => owner);
}

/**
 * Returns the configured sites.
 * @returns {Promise<Object[]>} The sites
 */
async function getSites(_, { tab }) {
  const { origin } = new URL(tab.url);

  if (!isTrustedOrigin(origin)) {
    return []; // don't give out any information
  }
  const projects = await Promise.all((await getConfig('sync', 'projects') || [])
    .map(async (handle) => {
      const project = (await getConfig('sync', handle));
      return {
        ...project,
        org: project.org || project.owner,
        site: project.site || project.repo,
      };
    }));
  return projects;
}

/**
 * Adds a configured site.
 * @returns {Promise<boolean>} True if the site was added, else false
 */
async function addSite({ config, idp, tenant }, { tab }) {
  const { origin } = new URL(tab.url);

  if (!isTrustedOrigin(origin)) {
    return false; // don't add anything
  }

  const owner = config.owner || config.org;
  const repo = config.repo || config.site;
  if (owner && repo) {
    // pass through login hint
    const loginHint = {
      idp,
      tenant,
    };

    return addProject({
      owner,
      repo,
    }, false, loginHint);
  } else {
    log.warn('addSite: missing required parameters org (or owner) and site (or repo)');
    return false;
  }
}

/**
 * Updates a configured site.
 * @returns {Promise<boolean>} True if the site was updated, else false
 */
async function updateSite({ config }, { tab }) {
  const { origin } = new URL(tab.url);

  if (!isTrustedOrigin(origin)) {
    return false; // don't update anything
  }

  const owner = config.owner || config.org;
  const repo = config.repo || config.site;
  if (owner && repo) {
    const project = await getConfig('sync', `${owner}/${repo}`);
    if (!project) {
      log.warn(`updateSite: project ${owner}/${repo} not found`);
      return false;
    }
    return !!(await updateProjectConfig({
      ...project,
      ...config,
    }));
  } else {
    log.warn('updateSite: missing required parameters org (or owner) and site (or repo)');
    return false;
  }
}

/**
 * Removes a configured site.
 * @returns {Promise<boolean>} True if the site was removed, else false
 */
async function removeSite({ config }, { tab }) {
  const { origin } = new URL(tab.url);

  if (!isTrustedOrigin(origin)) {
    return false; // don't update anything
  }
  const owner = config.owner || config.org;
  const repo = config.repo || config.site;
  if (owner && repo) {
    return deleteProject({
      owner,
      repo,
    });
  } else {
    log.warn('removeSite: missing required parameters org (or owner) and site (or repo)');
    return false;
  }
}

/**
 * Launches the sidekick in the sender's tab.
 * @returns {Promise<boolean>} True if sidekick launched, else false
 */
async function launch({
  owner, repo, org, site,
}, { tab }) {
  owner = org || owner;
  repo = site || repo;
  if (owner && repo) {
    // launch sidekick with owner and repo on this url
    await urlCache.set(tab, { owner, repo });
    await setDisplay(true);
    return true;
  } else {
    log.warn('launch: missing required parameters org and site or owner and repo');
    return false;
  }
}

/**
 * Starts the login flow for a given org.
 * @returns {Promise<boolean>} True if login flow started, else false
 */
async function login({
  owner, repo, org, site, idp, selectAccount = false, tenant,
}, { tab }) {
  owner = org || owner;
  repo = site || repo;
  const { origin } = new URL(tab.url);
  if (!isTrustedOrigin(origin)) {
    log.warn(`login: untrusted origin '${origin}'`);
    return false;
  }
  if (idp && !['google', 'microsoft', 'adobe'].includes(idp)) {
    log.warn(`login: unsupported idp '${idp}'`);
    return false;
  }
  if (owner && repo) {
    // start login flow for this org
    const params = new URLSearchParams();
    params.set('extensionId', chrome.runtime.id);
    if (idp) {
      params.set('idp', idp);
    }
    if (tenant) {
      params.set('tenantId', tenant);
    }
    if (selectAccount) {
      params.set('selectAccount', 'true');
    }
    const loginUrl = createAdminUrl({ owner, repo }, 'login', '', params);
    const loginTab = await chrome.tabs.create({
      url: loginUrl.toString(),
      openerTabId: tab.id,
      windowId: tab.windowId,
    });
    return new Promise((resolve) => {
      // close login tab on admin response
      const adminResponseListener = async (message, sender) => {
        if (sender.tab.id === loginTab.id && message.action === 'updateAuthToken') {
          await chrome.tabs.remove(loginTab.id);
          chrome.runtime.onMessageExternal.removeListener(adminResponseListener);
          resolve(true);
        } else {
          resolve(false);
        }
      };
      chrome.runtime.onMessageExternal.addListener(adminResponseListener);
    });
  } else {
    log.warn('launch: missing required parameters org (or owner) and site (or repo)');
    return false;
  }
}

/**
 * Adds or removes a project based on the tab's URL
 * @param {chrome.tabs.Tab} tab The tab
 */
async function addRemoveProject(tab) {
  const matches = await getProjectMatches(await getProjects(), tab);
  let config;
  if (matches.length === 1) {
    [config] = matches;
  } else {
    // multiple matches, check if the content script has a stored project selection
    try {
      config = await chrome.tabs.sendMessage(tab.id, { action: 'getStoredProject' });
    } catch (e) {
      // content script not available
    }
    if (!config) {
      // multiple matches but no stored project, ask user to pick first
      await showSidekickIfHidden();
      await showSidekickNotification(tab.id, {
        message: chrome.i18n.getMessage('config_project_pick_first'),
        headline: chrome.i18n.getMessage('config_project_pick'),
      });
      return;
    }
  }

  await showSidekickIfHidden();
  if (isValidProject(config)) {
    const { owner, repo } = config;
    let project = await getProject(config);
    if (!project) {
      await addProject(config);
      project = await getProject(config);
      const i18nKey = 'config_project_added';
      await showSidekickNotification(tab.id,
        {
          message: chrome.i18n.getMessage(i18nKey, project.project || project.id),
          headline: chrome.i18n.getMessage('config_add_project_headline'),
        },
        notificationConfirmCallback(tab.id));
    } else {
      await deleteProject(`${owner}/${repo}`);
      const i18nKey = 'config_project_removed';
      await showSidekickNotification(tab.id,
        {
          message: chrome.i18n.getMessage(i18nKey, project.project || project.id),
          headline: chrome.i18n.getMessage('config_remove_project_headline'),
        },
        notificationConfirmCallback(tab.id));
    }
  }
}

/**
 * Enables or disables a project based on the tab's URL
 * @param {chrome.tabs.Tab} tab The tab
 */
async function enableDisableProject(tab) {
  const matches = await getProjectMatches(await getProjects(), tab);
  let config;
  if (matches.length === 1) {
    [config] = matches;
  } else {
    // multiple matches, check if the content script has a stored project selection
    try {
      config = await chrome.tabs.sendMessage(tab.id, { action: 'getStoredProject' });
    } catch (e) {
      // content script not available
    }
    if (!config) {
      // multiple matches but no stored project, ask user to pick first
      await showSidekickIfHidden();
      await showSidekickNotification(tab.id, {
        message: chrome.i18n.getMessage('config_project_pick_first'),
        headline: chrome.i18n.getMessage('config_project_pick'),
      });
      return;
    }
  }

  const project = await getProject(config);
  if (!project) {
    return;
  }

  await showSidekickIfHidden();
  const enabling = project.disabled;
  const i18nKey = enabling
    ? 'config_project_enabled'
    : 'config_project_disabled';
  const i18nHeadlineKey = enabling
    ? 'config_project_enabled_headline'
    : 'config_project_disabled_headline';
  const notification = {
    message: chrome.i18n.getMessage(i18nKey, project.project || project.id),
    headline: chrome.i18n.getMessage(i18nHeadlineKey),
  };

  if (await toggleProject(config)) {
    if (enabling) {
      // reload tab so the content script and sidekick load before sending the notification
      await new Promise((resolve) => {
        chrome.tabs.onUpdated.addListener(function onComplete(tabId, info) {
          if (tabId === tab.id && info.status === 'complete') {
            chrome.tabs.onUpdated.removeListener(onComplete);
            resolve();
          }
        });
        notificationConfirmCallback(tab.id)();
      });
      // wait for sidekick to initialize after page load
      await waitForSidekick(tab.id);
    }
    await showSidekickNotification(
      tab.id,
      notification,
      !enabling ? notificationConfirmCallback(tab.id) : undefined,
    );
  }
}

/**
 * Opens the project admin tab.
 * @param {chrome.tabs.Tab} tab The tab
 */
async function manageProjects(tab) {
  await chrome.tabs.create({
    url: `https://tools.eueds.live/tools/project-admin/index.html`,
    openerTabId: tab.id,
    windowId: tab.windowId,
  });
}

/**
 * Opens the view document source popup.
 * @param {chrome.tabs.Tab} tab The tab
 */
async function openViewDocSource({ id }) {
  chrome.windows.create({
    url: chrome.runtime.getURL(`/views/doc-source/index.html?tabId=${id}`),
    type: 'popup',
    width: 740,
  });
}

/**
 * Checks if the view document source popup needs to be opened.
 * @param {number} id The tab ID
 */
export async function checkViewDocSource(id) {
  try {
    const tab = await chrome.tabs.get(id);
    if (!tab || !tab.url || !tab.active) {
      return;
    }
    const u = new URL(tab.url);
    const vds = u.searchParams.get('view-doc-source');
    if (vds && vds === 'true') {
      // @ts-ignore
      await openViewDocSource({ id });
    }
  } catch (e) {
    log.warn(`Error checking view document source for tab ${id}`, e);
  }
}

/**
 * Returns the user's profile picture.
 * @param {chrome.tabs.Tab} _ The tab
 * @param {Object} message The message object
 * @param {string} message.owner The project owner
 * @returns {Promise<string>} The user picture
 */
export async function getProfilePicture(_, { owner }) {
  if (!owner) {
    return undefined;
  }
  const projects = await getConfig('session', 'projects') || [];
  return projects.find((p) => p.owner === owner)?.picture;
}

/**
 * Tries to guess if a URL is an AEM site.
 * @param {chrome.tabs.Tab} _ The tab
 * @param {Object} message The message object
 * @param {string} message.url The URL to check
 * @returns {Promise<boolean>} True if the provided URL is an AEM site
 */
export async function guessAEMSite(_, { url }) {
  try {
    const resp = await fetch(url, { redirect: 'manual' }); // don't allow redirects
    if (resp.ok) {
      const mimeType = resp.headers.get('content-type');
      if (mimeType.startsWith('text/html')) {
        // payload must match pipeline output
        const payload = await resp.text();
        const [type, html, head, titl, link, meta] = payload.substring(0, 400).split('\n');
        return type === '<!DOCTYPE html>'
          && html.startsWith('<html')
          && head === '  <head>'
          && titl.startsWith('    <title>')
          && link.startsWith('    <link rel="canonical"')
          && meta.startsWith('    <meta');
      } else if (mimeType.startsWith('application/json')) {
        // payload must match pipeline output
        try {
          const payload = await resp.json();
          return !!payload[':type'];
        } catch (e) {
          // invalid json
          return false;
        }
      } else {
        // unable to guess. assume AEM
        return true;
      }
    } else {
      if (resp.status === 0 || resp.status === 404 || resp.status >= 500) {
        // unexpected redirect, not found or server error, assume incorrect prod setup
        return false;
      }
      // otherwise assume AEM (e.g. protected)
      return true;
    }
  } catch (e) {
    // unable to connect, assume AEM (e.g. firewalled)
    return true;
  }
}

/**
 * Closes the palette in the sender's tab.
 * @param {Object} message The message object
 * @param {string} message.id The palette ID to close
 * @param {chrome.runtime.MessageSender} sender The sender
 * @returns {Promise<boolean>} True if palette was closed, else false
 */
async function closePalette({ id }, { tab }) {
  if (!id) {
    log.info('closePalette: no palette id');
    return false;
  }
  if (!tab?.id) {
    log.warn('closePalette: no tab id');
    return false;
  }
  try {
    await chrome.tabs.sendMessage(tab.id, { action: 'close_palette', id });
    return true;
  } catch (e) {
    log.warn('closePalette: failed to send message', e);
    return false;
  }
}

/**
 * Closes the popover in the sender's tab.
 * @param {Object} message The message object
 * @param {string} message.id The popover ID to close
 * @param {chrome.runtime.MessageSender} sender The sender
 * @returns {Promise<boolean>} True if popover was closed, else false
 */
async function closePopover({ id }, { tab }) {
  if (!id) {
    log.info('closePopover: no popover id');
    return false;
  }
  if (!tab?.id) {
    log.warn('closePopover: no tab id');
    return false;
  }
  try {
    await chrome.tabs.sendMessage(tab.id, { action: 'close_popover', id });
    return true;
  } catch (e) {
    log.warn('closePopover: failed to send message', e);
    return false;
  }
}

/**
 * Updates a project based on the given message and sender.
 * @param {chrome.tabs.Tab} _ The tab
 * @param {Object} message The message object
 */
async function updateProject(_, { config }) {
  if (!config?.owner || !config?.repo) {
    return;
  }

  // only update if project exists and has different properties
  const existingProject = await getProject(config);
  if (existingProject) {
    const hasChanges = Object.keys(config)
      .filter((key) => key !== 'owner' && key !== 'repo')
      .filter((key) => config[key])
      .some((key) => {
        if (key === 'mountpoints') {
          return config[key][0] !== existingProject[key][0];
        } else if (key === 'project') {
          // don't override existing project name
          return !existingProject.project;
        } else {
          return config[key] !== existingProject[key];
        }
      });

    if (hasChanges) {
      await updateProjectConfig({
        ...existingProject,
        ...config,
      });
    }
  }
}

/**
 * Adds request headers for a given domain to bypass the browser cache.
 * @param {chrome.tabs.Tab} tab The tab
 * @param {Object} msg The message object
 * @param {string} msg.host The host to bust cache for (defaults to tab host)
 * @returns {Promise<boolean>} True if browser cache was busted, else false
 */
async function bustCache(tab, { host }) {
  if (!tab || !tab.url || !tab.active) {
    return false;
  }
  return addCacheBusterRule(host || new URL(tab.url).hostname);
}

/**
 * Adds request headers for a given domain to bypass the browser cache.
 * @param {Object} msg The message object
 * @param {string} msg.host The host to bust cache for (defaults to tab host)
 * @param {Object} sender The sender object
 * @param {chrome.tabs.Tab} sender.tab The tab
 * @returns {Promise<boolean>} True if browser cache was busted, else false
 */
async function externalBustCache({ host }, { tab }) {
  return bustCache(tab, { host });
}

/**
 * Resizes the palette in the sender's tab.
 * @param {Object} message The message object
 * @param {string} message.id The palette ID to resize
 * @param {Object} [message.rect] The rect object with properties width and/or height (CSS values)
 *   optional: top, left, right, bottom
 * @param {chrome.runtime.MessageSender} sender The sender
 * @returns {Promise<boolean>} True if palette was resized, else false
 */
async function resizePalette({
  id, rect,
}, { tab }) {
  if (!tab?.id) {
    log.warn('resizePalette: no tab id');
    return false;
  }
  if (!id) {
    log.info('resizePalette: no palette id');
    return false;
  }
  if (!rect || !rect.width || !rect.height) {
    log.info('resizePalette: no rect properties provided');
    return false;
  }
  try {
    await chrome.tabs.sendMessage(tab.id, {
      action: 'resize_palette',
      id,
      rect,
    });
    return true;
  } catch (e) {
    log.warn('resizePalette: failed to send message', e);
    return false;
  }
}

/**
 * Resizes the popover in the sender's tab.
 * @param {Object} message The message object
 * @param {string} message.id The popover ID to resize
 * @param {Object} [message.rect] The rect object with properties width and/or height (CSS values)
 * @param {chrome.runtime.MessageSender} sender The sender
 * @returns {Promise<boolean>} True if popover was resized, else false
 */
async function resizePopover({
  id, rect,
}, { tab }) {
  if (!tab?.id) {
    log.warn('resizePopover: no tab id');
    return false;
  }
  if (!id) {
    log.info('resizePopover: no popover id');
    return false;
  }
  if (!rect || !rect.width || !rect.height) {
    log.info('resizePopover: no rect properties');
    return false;
  }
  try {
    await chrome.tabs.sendMessage(tab.id, {
      action: 'resize_popover',
      id,
      rect,
    });
    return true;
  } catch (e) {
    log.warn('resizePopover: failed to send message', e);
    return false;
  }
}

/**
 * Actions which can be executed via internal messaging API.
 * @type {Object} The internal actions
 */
export const internalActions = {
  addRemoveProject,
  enableDisableProject,
  manageProjects,
  openViewDocSource,
  getProfilePicture,
  guessAEMSite,
  updateProject,
  saveDocument,
  bustCache,
};

/**
 * Actions which can be executed via external messaging API.
 * @type {Object} The external actions
 */
export const externalActions = {
  getAuthInfo,
  getSites,
  launch,
  login,
  addSite,
  updateSite,
  removeSite,
  updateAuthToken,
  resizePalette,
  resizePopover,
  closePalette,
  closePopover,
  bustCache: externalBustCache,
};
